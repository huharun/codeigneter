<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

require_once dirname(__FILE__) . '/tcpdf/tcpdf.php';

class Footer_tcpdf extends TCPDF
{



    // Page footer
    public function Footer() {
        // Position at 15 mm from bottom
        // $this->SetY(-310);
        // Set font
        //$this->SetFont('helvetica', 'I', 8);
        
        //preassessment-->reports->condonation attendance report(A4 L) pls check alignment
		//$this->Cell(220, 1,'Date Generated :'.date("d/m/Y h:i A"), '', 0, 'R', 0); 
        $this->SetY(-8);
        // Set font
        $this->SetFont('helvetica', 'I', 8);
		$this->Cell(190, 1,'Data Generated :'.date("d/m/Y h:i A"), '', 0, 'R', 0); 
		$this->SetFont('helvetica', 'B',11);
		$this->SetFont('helvetica', '', 9);
        // Page number
        $this->Cell(0, 10, 'Page '.$this->getAliasNumPage().'/'.$this->getAliasNbPages(), 0, false, 'C', 0, '', 0, false, 'T', 'M');
    }	
	
	
    function __construct()
    {
        parent::__construct();
    }
}

/* End of file Pdf.php */
/* Location: ./application/libraries/Pdf.php */
<!doctype.html>
<html>
<head>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>


</head>
<body>
    <?php foreach($details as $row)
    {
    ?>
<form style="padding: 4%; background-color: white" id="form" name="form" method="POST" action="<?php echo site_url('Assessment/new/'.$row['id']);?>">
    <h1>Edit Form</h1>
    <label for="name">Name</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    <input type="text" placeholder="enter full name" value="<?php echo $row['name']; ?>" name="name" id="name"  size="47">&nbsp 
    <br><br>
    <label for="institute">Institute</label>&nbsp&nbsp&nbsp&nbsp
    <input type="text" placeholder="institute" value="<?php echo $row['institute']; ?>"  name="institute" id="institute" size="47">
    <br><br>
    <label for="Email">Email</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    <input type="text" placeholder="example@gmail.com" value="<?php echo $row['email']; ?>"  name="email" id="email" size="47">
    <br><br>
    <label for="phone">Phone</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    <input type="text" placeholder="phone" value="<?php echo $row['phone']; ?>" name="phone" id="phone" size="47">
    <br><br>
    <label for="date">DOB</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    <input type='date' name='dob' id="dob" value="<?php echo $row['dob']; ?>"> <br/><br/>
    <div style="line-height: 47px; height: 8">
    <label>Gender</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    <input type="radio" name="gender" value="Male" <?php echo $row['gender']; ?> checked/>Male
    <input type="radio" name="gender" value="Female" <?php echo $row['gender']; ?> checked />Female
    </div>
    <br><br>
    <label for="subject">Subject</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    <select name="subject" id="subject" value="<?php echo $row['subject']; ?>" >
    <option value="maths">Maths</option>
    <option value="physics">Physics</option>
    <option value="chemistry">Chemistry</option>
    </select>
    <br><br>
    <button type="submit" id="submit" name="update" value="update">Update</button>
    <?php
    }
    ?>
</form>
  
<div class="container">
    <div class="form-group">
         <form style="padding: 4%;" name="forme" method="POST" action="<?php echo base_url().'index.php/Assessment/storePost'?>" enctype = "multipart/form-data" >
            <div class="table-responsive">  
                <table class="table table-bordered" id="dynamic_field">  
                    <tr>  
        <?php $i=1;
        for ($data = 0; $data < 1; $data++) { 
        ?>
                        <td><input type="text" name="<?php echo $i?>qualification" placeholder="Enter your qualification" class="form-control name_list" value="<?php echo $i['qualification']; ?>" required="" /></td> 
                        <td><input type="text" name="<?php echo $i?>complete" placeholder="completion year" class="form-control name_list" value="<?php echo $i['complete']; ?>" required="" /></td> 
                        <td><input type="file" name="<?php echo $i?>stu_file" placeholder="upload document" class="form-control name_list" value="<?php echo $i?>'stu_file'; ?>" required="" /></td>  
                        <td><button type="button" name="add" id="add" class="btn btn-success">+</button></td>  

                        <td><button type="submit" name="submit" id="submit" class="btn btn-info" value="Submit" >save</button></td>
        <?php
        $i++;}
        ?>

                    </tr>  
                </table>       
            </div>
        </div> 
    </div>
</form>

    
<!-- <script>
$(document).ready(function(){
    $("form").validate({
        rules: {
            name:{
            required:true,
            },
            email:{
            required:true,
            email:true,
            },
            DOB:{
            required:true,
            minlength:10,
            maxlength:10,
            digits:true,
  },
            institute:{
            required:true,
            },
            subject:{
                required:true,
            },
            
        },
        messages: { 
        //'name':'Enter Full name',
        'email': 'Enter a valid email',
        'number': 'Enter a valid number',
},
});
});
</script> -->

<script type="text/javascript">
    $(document).ready(function(){      
    var i=1;  
    $('#add').click(function(){  
    i++;  
    $('#dynamic_field').append('<tr id="row'+i+'" class="dynamic-added"><td><input type="text" name="'+i+'qualification" placeholder="Enter your qualification" class="form-control name_list" required /></td><td><input type="text" name="'+i+'complete" placeholder="completion year" class="form-control name_list" required /></td><td><input type="file" name="'+i+'stu_file" placeholder="upload document" class="form-control name_list" required /></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></td></tr>');  
      });


    $(document).on('click', '.btn_remove', function(){  
    var button_id = $(this).attr("id");   
    $('#row'+button_id+'').remove();  
    });  
});  
</script>

<style type="text/css">
    

h1{
   color:red;
   text-align:center;
   font-family: monospace;
}

body{
   padding:  15.3%;
   font-family: sans-serif;
   font-size: large;
   background-color: lightblue;
}

div{
   background-color: white;
   display: flex;
}

button{
   background-color: red;
   border-color: red;
}  

input{
   background-color: lightgray;
   border: none;
   height: 40px;
}

select{
   background-color: lightgray;
   border: none;
   height: 40px;
}

input[type="radio"]+label{
   height: 10px;
}

</style>

</body>
</html>

<html xmlns="http://www.w3.org/1999/xhtml">  
<head>  
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />  
    <title>Registered Members</title>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.js" integrity="sha512-n/4gHW3atM3QqRcbCn6ewmpxcLAHGaDjpEBu4xZd47N0W2oQ+6q7oc3PXstrJYXcbNU1OHdQ1T7pAP+gi5Yu8g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" type="text/css" href="assets/plugins/bootstrap-3.3.5/dist/css/bootstrap.css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
</head> 

<body  style="background-color: lightblue; font-style: sans-serif;"> <br>
    <div style="height: 50px; background-color: lightcoral; border-radius: 10px;">
        <h1 style=" color: black;">Registered Members</h1>
            <div style="position: absolute; right: 10; top: 53px;" >
            <a class="button-33" style="margin-right:40px" href="<?php echo site_url('Assessment/export'); ?>"><i class="fa fa-file-excel-o"></i>Excel</a>
            <a class="button-33" href=<?php echo site_url('Assessment/pdf_download'); ?>>PDF</a> 
            <a class="button-33"  href="<?php echo site_url('Assessment/add');?>">Add</a>
            </div>
    </div>

<div class="container mt-3">
  <div class="mt-2">
    <table style="background-color:white" id="data" border="1">
        <thead> 
            <tr style="background-color: lightgray; font-weight: bold;">
            <!-- <td>ID</td> -->
            <td>Name</td>  
            <td>Institute</td>
            <td>Email</td>
            <td>Phone</td>
            <td>DOB</td>
            <td>Gender</td>
            <td>Subject</td>
            <!-- <td>Qualification</td>
            <td>completion</td>
            <td>file</td> -->
            <!-- <td>Details</td> -->
            <!-- <td>Action</td> -->
            <td>Action</td>  
            </tr> 
        </thead>

        <tbody>
        </tbody> 

   </table>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/5.5.2/bootbox.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

<script>
    $.noConflict();
    $(document).ready(function() {
    $('#data').dataTable({
        "sDom": 'T<"clear">lfrtip',
        "TableTools": {
        },
        "sPaginationType": "full_numbers",
        "bJQueryUI": false,
        "bAutoWidth": false,
        "bLengthChange": true,
        'bProcessing': false,
        "bSearchable": true,
        'bServerSide': true,
        'sAjaxSource': '<?php echo site_url('Assessment/table'); ?>',
        'aoColumns':
        [
            // { 'sName': 'S.professor_id',"bVisible":false},
            // {'sName': 'id'},
            {'sName': 'name'},
            {'sName': 'institute'},
            {'sName': 'email'},
            {'sName': 'phone'},
            {'sName': 'dob'},
            {'sName': 'gender'},
            {'sName': 'subject'},
            {'sName': 'action', "bSortable": false},
        ],
            "aaSorting": [[2, "ASC"]],
            'fnServerData': function (sSource, aoData, fnCallback)
            {
                $.ajax({
                    'dataType': 'json',
                    'type': 'POST',
                    'url': sSource,
                    'data': aoData,
                    'success': fnCallback
                });
            },
            "fnDrawCallback": function () {
                $("#data").removeClass('no-footer');
            }

        });

});

</script>


<style type="text/css">

.button-33 {
  background-color: #c2fbd7;
  border-radius: 100px;
  box-shadow: rgba(44, 187, 99, .2) 0 -25px 18px -14px inset,rgba(44, 187, 99, .15) 0 1px 2px,rgba(44, 187, 99, .15) 0 2px 4px,rgba(44, 187, 99, .15) 0 4px 8px,rgba(44, 187, 99, .15) 0 8px 16px,rgba(44, 187, 99, .15) 0 16px 32px;
  color: green;
  cursor: pointer;
  display: inline-block;
  font-family: CerebriSans-Regular,-apple-system,system-ui,Roboto,sans-serif;
  padding: 7px 20px;
  text-align: center;
  text-decoration: none;
  transition: all 250ms;
  border: 0;
  font-size: 16px;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
}

.button-33:hover {
  box-shadow: rgba(44,187,99,.35) 0 -25px 18px -14px inset,rgba(44,187,99,.25) 0 1px 2px,rgba(44,187,99,.25) 0 2px 4px,rgba(44,187,99,.25) 0 4px 8px,rgba(44,187,99,.25) 0 8px 16px,rgba(44,187,99,.25) 0 16px 32px;
  transform: scale(1.05) rotate(-1deg);
}
</style>

</body>  
</html>  
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
	<title>Assesment</title>
</head>

<body>
  <form id="form" name="form" method="POST" enctype='multipart/form-data' action="<?php echo site_url('Assessment/savedata');?>">
    <h1>Student Form</h1>
    <label for="name">Name</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    <input type="text" placeholder="enter full name" name="name" id="name" size="47">&nbsp 
    <br><br>
    <label for="institute">Institute</label>&nbsp&nbsp
    <input type="text" placeholder="institute" name="institute" id="institute" size="47">
    <br><br>
    <label for="Email">Email</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    <input type="text" placeholder="example@gmail.com" name="email" id="email" size="47">
    <br><br>
    <label for="phone">Phone</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    <input type="text" placeholder="phone" name="phone" id="phone" size="47">
    <br><br>
    <label for="dob">DOB</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    <input type="date" name="dob" id="dob" size="47">
    <br><br>
    <div class="wrap">
    <label >Gender</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        <input type="radio" name="gender" value="Male"/>Male
        <input type="radio" name="gender" value="Female"/>Female
    </div>
    <br><br>
    <label for="subject">Subject</label>
    <br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    <select name="subject" id="subject">
        <option value="maths">Maths</option>
        <option value="physics">Physics</option>
        <option value="chemistry">Chemistry</option>
    </select>
    <br><br>
    <button type="submit" id="submit" name="submit" value="submit">Register</button>
  </form>

<script>
$(document).ready(function(){
    $("form").validate({
        rules: {
            name:{
            required:true,
            },
            email:{
            required:true,
            email:true,
            },
            phone:{
            required:true,
            minlength:10,
            maxlength:10,
            digits:true,
  },
            institute:{
            required:true,
            },
            subject:{
                required:true,
            },
            
        },
        messages: { 
        //'name':'Enter Full name',
        'email': 'Enter a valid email',
        'number': 'Enter a valid number',
},
});

});
</script>

<style type="text/css">

label{
    font-weight: bolder;
}

#subject{
    height: 30px;
    width: 400px;
}

.wrap {
  display: flex;
  align-items: center;
}

input {
  margin: 0;
}

body {
    margin:0;
    font-family:arial,tahoma,sans-serif;
    font-size:12px;
    font-weight:normal;
    direction:ltr;
  background:lightblue;
}

.container{
  margin: 0px auto;
  height: auto;
  width: 50px;
  padding: 0px;
}


button {
    padding:15px 50px;
    width:auto;
    background:#1abc9c;
    border:none;
    color:white;
    cursor:pointer;
    display:inline-block;
    float:right;
    clear:right;
    -webkit-transition:0.2s ease all;
       -moz-transition:0.2s ease all;
        -ms-transition:0.2s ease all;
         -o-transition:0.2s ease all;
            transition:0.2s ease all;
}

button:hover {
    opacity:0.8;
}

button:active {
    opacity:0.4;
} 

form {
    margin:10% auto 0 auto;
    padding:30px;
    width:400px;
    height:auto;
    overflow:hidden;
    background:white;
    border-radius:10px;
}

form input {
    margin:15px 0;
    padding:15px 10px;
    width:100%;
    outline:none;
    border:1px solid #bbb;
    border-radius:20px;
    display:inline-block;
    -webkit-box-sizing:border-box;
       -moz-box-sizing:border-box;
            box-sizing:border-box;
    -webkit-transition:0.2s ease all;
       -moz-transition:0.2s ease all;
        -ms-transition:0.2s ease all;
         -o-transition:0.2s ease all;
            transition:0.2s ease all;
}

form input[type=text]:focus,
form input[type="password"]:focus {
    border-color:cornflowerblue;
}


}
select{
    background-color: lightgray;
    border: none;
    height: 40px;
}
input[type="radio"]+label{
    height: 10px;
}

 h1 {
text-align: center;
    font-size:30px; font-weight:300; color:#222; letter-spacing:1px;
    text-transform: uppercase;

    display: grid;
    grid-template-columns: 1fr max-content 1fr;
    grid-template-rows: 27px 0;
    grid-gap: 20px;
    align-items: center;
}

 h1:after, h1:before {
    content: " ";
    display: block;
    border-bottom: 1px solid #c50000;
    border-top: 1px solid #c50000;
    height: 5px;
  background-color:#f8f8f8;
}
</style>

</body>
</html>
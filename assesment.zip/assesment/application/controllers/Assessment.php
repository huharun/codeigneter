<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Assessment extends CI_Controller {

	public function __construct() { 
	   parent::__construct();
		$this->load->model('asses_model');

	}
	public function index()
	{
		//load database and listing page
		$this->load->database('assessment');
		$data['details']=$this->asses_model->select();  
      $this->load->view('list', $data);  	
	}

	 public function table()
	{
	   //Datatable Listener 
  	   $this->load->library('datatables');
		$this->datatables
		->select('id,name,institute,email,phone,dob,gender,subject')
		->from('details');

		$links = '<center><a href= "' . site_url('Assessment/edit/$1') . '" title="Edit" class="tip"><i class="fa fa-edit text-info"></i></a>&nbsp;&nbsp;';
			
		$links.='<a href= "' . site_url('Assessment/delete/$1') . '" class="delCourse" data-courseId=$1  title="Delete" class="tip"><i data-courseId=$1 class="fa fa-trash text-danger"></i></a>&nbsp;&nbsp;';
		
      $this->datatables->add_column('action', $links, 'id');
	
      $this->datatables->unset_column('id');
			
		echo $this->datatables->generate();
		
		
		
	}

	public function add()
	{
		//add form details
		$this->load->view('add');
	}
	public function savedata()

	{
		//save the add form details
		if($this->input->post('submit'))
		{
			$data=array(
			'name'=> $this->input->post('name'),
			'institute'=>$this->input->post('institute'),
			'email'=>$this->input->post('email'),
			'phone'=>$this->input->post('phone'),
			'dob'=>$this->input->post('dob'),
			'gender'=>$this->input->post('gender'),
			'subject'=>$this->input->post('subject'),

			);
			$response=$this->asses_model->save($data);

			if($response==1){
				echo '<script>alert("You Have Successfully updated this Record!");</script>';

		 	 	redirect('Assessment');
			}
			else{
				echo "Insert error";
			}
		 }
		 	else{
		 	 	redirect('Assessment');
    		}
	}

	public function edit($id) 
	{		
      //edit the details on list page
      $data['details']=$this->asses_model->fetchdatabyid($id,'details');
      $this->load->view('edit',$data);
    }
	
	public function delete($id)
	{
		//delete a row
		$this->asses_model->delete($id);
		redirect('Assessment');
	}

	public function new($id)
	{
		//edit form by changing user data 	 	       
		if(isset($_POST)){
      $data['name']=$this->input->post('name');
		$data['institute']=$this->input->post('institute');
		$data['email']=$this->input->post('email');
		$data['phone']=$this->input->post('phone');
		$data['dob']=$this->input->post('dob');
		$data['gender']=$this->input->post('gender');
		$data['subject']=$this->input->post('subject');
		$data['qualification']=$this->input->post('qualification');
		$data['complete']=$this->input->post('complete');
		$data['file']=$this->input->post('file');

		$this->asses_model->edit($id,$data);
		redirect('Assessment');
		
      }
	}
	
 public function pdf_download(){

 		//pdf library loading
		$bio_data =$this->asses_model->retrive_pdf();
		$this->load->library('footer_tcpdf');
		$pdf = new footer_tcpdf(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false); 

      //setting table format 
     	$pdf->setFontSubsetting(true);
     	$pdf->SetFont('helvetica', '', 6);
     	$pdf->AddPage('','');
	   $pdf->SetMargins(5, true); // set the margins
	   $pdf->SetFont('Helvetica', '');
	   $pdf->SetFontSize(9);
	   $pdf->Cell(180, 7, ' Details', '', 0, 'C', 0);
	   $pdf->ln();
	   $pdf->ln();

     	$pdf->SetFontSize(10);


     	//Selecting cell Title value and size

     	// $pdf->SetFont('Helvetica', 'B');
     	// $pdf->Cell(10, 9, 'id', 'TBRL', 0, 'L', 0);

     	$pdf->SetFont('Helvetica', 'B');
     	$pdf->Cell(15,9 , 'Name', 'TBRL', 0, 'L', 0);

     	$pdf->SetFont('Helvetica', 'B');
     	$pdf->Cell(35, 9, 'Institute', 'TBRL', 0, 'L', 0);
     	// $pdf->ln();

     	$pdf->SetFont('Helvetica', 'B');
     	$pdf->Cell(30, 9, 'Email', 'TBRL', 0, 'L', 0);

     	$pdf->SetFont('Helvetica', 'B');
     	$pdf->Cell(15, 9, 'Phone', 'TBRL', 0, 'L', 0);

     	// $pdf->SetFont('Helvetica', '');
     	// $pdf->Cell(15, 9, 'dob', 'TBRL', 0, 'L', 0);

     	$pdf->SetFont('Helvetica', 'B');
     	$pdf->Cell(15, 9, 'Gender', 'TBRL', 0, 'L', 0);

     	$pdf->SetFont('Helvetica', 'B');
     	$pdf->Cell(15, 9, 'Subject', 'TBRL', 0, 'L', 0);


     	$pdf->SetFont('Helvetica', 'B');
     	$pdf->Cell(23, 9, 'Qualification', 'TBRL', 0, 'L', 0);

     	$pdf->SetFont('Helvetica', 'B');
     	$pdf->Cell(17, 9, 'Complete', 'TBRL', 0, 'L', 0);

     	$pdf->SetFont('Helvetica', 'B');
     	$pdf->Cell(45, 9, 'File', 'TBRL', 0, 'L', 0);
    
     	$pdf->ln();





	$final=array();
	foreach ($bio_data as $val=>$rev) {
     
    	//Selecting cell body value and size

	   // $pdf->MultiCell(10, 9,$rev['id'] , 1, 'L', 0, 0, '', '', true);

	   $pdf->MultiCell(15, 9,ucfirst($rev['name']) , 1, 'L', 0, 0, '', '', true);

      $pdf->MultiCell(35, 9,ucfirst($rev['institute']) , 1, 'L', 0, 0, '', '', true);
	           
	   $pdf->MultiCell(30, 9,($rev['email']) , 1, 'L', 0, 0, '', '', true);

	   $pdf->MultiCell(15, 9,($rev['phone']) , 1, 'L', 0, 0, '', '', true);

	   // $pdf->MultiCell(15, 9,($rev['dob']) , 1, 'L', 0, 0, '', '', true);

	   $pdf->MultiCell(15, 9,ucfirst($rev['gender']) , 1, 'L', 0, 0, '', '', true);

	   $pdf->MultiCell(15, 9,ucfirst($rev['subject']) , 1, 'L', 0, 0, '', '', true);

	   $pdf->MultiCell(23, 9,ucfirst($rev['qualification']) , 1, 'L', 0, 0, '', '', true);

	   $pdf->MultiCell(17, 9,ucfirst($rev['complete']) , 1, 'L', 0, 0, '', '', true);

	   $pdf->MultiCell(45, 9,ucfirst($rev['file']) , 1, 'L', 0, 0, '', '', true);

		$pdf->ln();
	}

		ob_end_clean();
					
		//download and view output
		$pdf->Output('details', 'I');
}


public function export()
 	{
 	 $file_name = 'details'.date('Ymd').'.csv'; 
     header("Content-Description: File Transfer"); 
     header("Content-Disposition: attachment; filename=$file_name"); 
     header("Content-Type: application/csv;");
   
     // get data 
     $details = $this->asses_model->export();
  	 //echo '<pre>';print_r($details);exit;
     // file creation 
     $file = fopen('php://output', 'w');
 
     $header = array('name','institute','email','phone','dob','gender','subject'); 
     fputcsv($file, $header);
     foreach ($details as $row)
     { 
     fputcsv($file, $row); 
     }
     fclose($file);
     exit;
 }


 public function storePost()
    {
    	//multiple file uploading
		$data = [];
      $count = count($_FILES);
 		
      for($i=1;$i<=$count;$i++){
  
        if(!empty($_FILES[$i.'stu_file'])){
         
          $config['upload_path'] = 'C:\xampp\htdocs\assesment\uploads'; 
          $config['allowed_types'] = 'jpg|jpeg|png|gif|pdf';
          $config['max_size'] = '5000'; // max_size in kb
          $config['file'] = $_FILES[$i.'stu_file'];
          $this->load->library('upload',$config);

       
         if($this->upload->do_upload($i.'stu_file')){         		
           	$uploadData = $this->upload->data();   
           	// echo '<pre>ssxx';print_r($uploadData);exit;        
            $fullPath = base_url() .'detail'. $uploadData['file_name']; 
            $filename = $uploadData['file_name']; 
            $data['response'] = 'successfully uploaded '.$filename; 
         }else{          	
            $data['response'] = $this->upload->display_errors();; 
         }      
      	}else{ 
         	$data['response'] = 'failed'; 
      	} 		

				//post data into database
				if(!empty($_POST)){
        		$details=($_POST);
       		$data=array(
       		'qualification'=> $details[$i.'qualification'],
				'complete'=>$details[$i.'complete'], 
				'file'=>$filename);		
				$this->db->insert('detail',$data);
          }


}

  redirect('Assessment'); 
}
} 
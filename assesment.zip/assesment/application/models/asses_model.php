<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class asses_model extends CI_Model {
   
   public function select() {  
   //selecting table and listing   
      $query = $this->db->get('details');  
      return $query->result_array();  
   }

   public function save($data){
   //insert form data to database
      $this->db->insert('details',$data);
      return true;
   }
   
   public function edit($id,$data){
   //edit user details
      $this->db->where('id', $id);
      return $this->db->update('details', $data);
   }
      
   public function fetchdatabyid($id,$table){
   //selecting data by id
      $this->db->where('id',$id);
      $data=$this->db->get($table);
      return $data->result_array();
   }

   public function delete($id){
   //delete row 
      $this -> db -> where('id', $id);
      $this -> db -> delete('details');
   }

   public function add_link_to_db($filename){
   //showing upload file by name 
      return $last_id = $this->db->insert('details', ['name'=>$filename]);
   }

   public function import() {
   //import detail from excel
      $this->db->select(array( 'name', 'institute', 'email', 'phone','dob', 'gender','subject'));
      $this->db->from('details');  
      $query = $this->db->get();
      return $query->result_array();
   }

   public function retrive_pdf(){
   //pdf export
     $this->db->select('U.qualification,U.complete,U.file,S.name,S.institute,S.email,S.phone,S.gender,S.subject');
     $this->db->from('detail U,details S');
     $query = $this->db->get();
     return $query->result_array();
   }

   public function export(){
   //export as excel and csv
      $this->db->select('name,institute,email,phone,dob,gender,subject');
      $this->db->from('details');  
      $query = $this->db->get();
      return $query->result_array();
   }
     
}
?>
